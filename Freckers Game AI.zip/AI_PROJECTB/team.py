metadata = {
    "team_name": "Jin_Nic_CodeTitans",
    "team_members": [
        {
            "name": "Nicolai Skogstad",
            "student_id": "1480099",
            "email": "nskogstad@student.unimelb.edu.au"
        },
        {
            "name": "Jin-Oh Youm",
            "student_id": "1394258",
            "email": "jyoum@student.unimelb.edu.au"
        }
    ]
}
